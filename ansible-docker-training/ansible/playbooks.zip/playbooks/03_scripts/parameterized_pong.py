#!/usr/bin/env python3

import sys

name = sys.argv[1]

print(f"pong {name}")

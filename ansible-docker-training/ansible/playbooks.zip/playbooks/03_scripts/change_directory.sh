#!/bin/bash

cd ..
pwd
